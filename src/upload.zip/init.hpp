// init.hpp

#ifndef __init_H__
#define __init_H__
#include "example.hpp"
#include "SGL2.hpp"

#ifndef CPORTA

#endif

namespace SGL2 {
	void init();
}
#endif


